
//!! test Micro-IC (!! trucks may change to cars due to init truck frac)

if(false){
    types  =[0,    0,    1,    0];
    lengths=[8,    5,    14,   7];
    widths =[4.5,  4,    6,  4.5];
    longPos=[150,  160,  170,  180];
    lanes  =[0,    1,    2,    0];
    speeds =[25,   25,   0,   30];
    mainroad.initializeMicro(types,lengths,widths,longPos,lanes,speeds);
}
