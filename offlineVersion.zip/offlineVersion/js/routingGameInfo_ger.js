
// showInfo() from control_gui.js does not work if loaded locally.
// Replace by direct string defined here in the source
// newline in source escaped with '\'


var infoString="<h2> Playing Directions</h2>\
<ul>\
  <li> Press \"Play Routing Game\" to start the game</li>\
<li> Avoid congestions by controlling the deviation usage with the slider</li>\
<li> The main inflow is externally controlled. No new vehicles will enter after some time</li>\
<li> The game ends when all regular vehicles have left the simulation</li>\
<li> The shortest time wins</li>\
</ul>";

